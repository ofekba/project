import sys
import numpy as np
from matplotlib import pyplot as plt

fp = open("dists.reax","r") 
text=fp.read() 

text_list = text.split("\n")
timeStep=0
timeStep_index=0
atom_tag=0
atom_type=0
neigh_tag=0
neigh_dist=0

total_timesteps=6000
ln=text_list[0].split(" ")
if ln[1] == "totalTimesteps":
	total_timesteps=int(ln[2])
print(ln)
print(total_timesteps)
total_timesteps=6000
	
neverty_fix_check=1

size=int(total_timesteps/neverty_fix_check) + 1

arr=np.zeros((size, 117, 117))
axis_x=[]


#print(text_list)

for line in text_list:
	ln=line.split(" ")
	i=0 #iterator on the line
	if ln[i]=="#":
		i+=1
	if(i>=len(ln)):
		continue;
	elif ln[i]=="Timestep":
		timeStep=int(ln[i+1])
		timeStep_index=int(timeStep/neverty_fix_check)
		axis_x.append(timeStep)
		continue;
	elif ln[i]=="atom":
		atom_tag=int(ln[i+1])
		atom_type=int(ln[i+3])
		i+=4
		j=i #iterator for atoms line
		while j < len(ln)-1:
			neigh_tag=int(ln[j])
			j+=1
			neigh_dist=float(ln[j])
			j+=1
			arr[timeStep_index][atom_tag-1][neigh_tag-1]=neigh_dist

#print(list(range(11)),"\n")
#print(arr)
print("finish parsing")

typedict =	{
  "C": 1,
  "H": 2,
  "O": 3,
  "N": 4
}

axis_y=[ [], [], [], [], [], [], [], []]
for j in range(timeStep_index+1):
	axis_y[0].append(arr[j][91][95]) #C-O dist
	axis_y[1].append(arr[j][95][28]) #O-H dist
	axis_y[2].append(arr[j][7][28]) #N-H dist
	axis_y[3].append(arr[j][7][91]) #N-C dist
	axis_y[4].append(arr[j][51][53]) #C-O dist
	axis_y[5].append(arr[j][53][27]) #O-H dist
	axis_y[6].append(arr[j][7][27]) #N-H dist
	axis_y[7].append(arr[j][7][51]) #N-C dist


plt.plot(axis_x,axis_y[4], label="C(52)-O(54)")
plt.plot(axis_x,axis_y[5], label="H(28)-O(54)")
plt.plot(axis_x,axis_y[6], label="N(8)-H(28)")
plt.plot(axis_x,axis_y[7], label="N(8)-C(52)")
#, linestyle='--'


plt.legend(loc='upper right')
#bbox_to_anchor=(1.05, 1), , borderaxespad=0.
plt.xlabel("timeStep")
plt.ylabel("distance")
plt.title("Distance Between Atoms As A Function Of Time")
plt.show()

plt.plot(axis_x,axis_y[0], label="C(92)-O(96)")
plt.plot(axis_x,axis_y[1], label="H(29)-O(96)")
plt.plot(axis_x,axis_y[2], label="N(8)-H(29)")
plt.plot(axis_x,axis_y[3], label="N(8)-C(92)")
plt.legend(loc='upper right')
plt.xlabel("timeStep")
plt.ylabel("distance")
plt.title("Distance Between Atoms As A Function Of Time")
plt.show()


e_fp = open("energy.reax","r") 
text=e_fp.read() 
text_list = text.split("\n")

text_list=text_list[1:]
#print(text_list)
y=[]
for e in text_list:
	if e == "finish":
		y.append(0.0)
	elif e == "start":
		continue;
	else:
		y.append(float(e))

x=list(range(len(y)))

plt.plot(x,y)
plt.xlabel("timeStep")
plt.ylabel("energy")
plt.title("Additional Energy As A Function Of Time")
plt.show()

	





		
		
		
			
			
		
